/*
 * Copyright 2018 Google, Inc.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are
 * met: redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer;
 * redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution;
 * neither the name of the copyright holders nor the names of its
 * contributors may be used to endorse or promote products derived from
 * this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "systemc/core/process.hh"
#include "systemc/ext/core/messages.hh"
#include "systemc/ext/core/sc_event.hh"
#include "systemc/ext/core/sc_join.hh"
#include "systemc/ext/core/sc_module.hh"
#include "systemc/ext/utils/sc_report_handler.hh"

namespace sc_core
{

sc_join::sc_join() : remaining(0) {}

void
sc_join::add_process(sc_process_handle h)
{
    auto p = (::sc_gem5::Process *)h;
    assert(p);

    if (p->procKind() == SC_METHOD_PROC_) {
        SC_REPORT_ERROR(SC_ID_JOIN_ON_METHOD_HANDLE_, "");
        return;
    }

    remaining++;
    p->joinWait(this);
}

int sc_join::process_count() { return remaining; }
void sc_join::signal() { if (!--remaining) joinEvent.notify(); }
void sc_join::wait() { ::sc_core::wait(joinEvent); }
void sc_join::wait_clocked() { do { ::sc_core::wait(); } while (remaining); }

} // namespace sc_core
